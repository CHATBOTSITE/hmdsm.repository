import xbmcaddon

MainBase = 'https://pastebin.com/raw/DPvKSm9v'
addon = xbmcaddon.Addon('plugin.video.acdcIPTV')
