import xbmcaddon

MainBase = 'http://pastebin.com/tfgUtRyJ'
addon = xbmcaddon.Addon('plugin.video.amerikano')